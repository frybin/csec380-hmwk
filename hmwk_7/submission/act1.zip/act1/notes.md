Test user session - 3f1831860f5dfee7ec05d1 (first login)
Test user session - 8b39ac2d944d047d15a991 (logout, then 2nd login)

New session is generated each time a user logs in